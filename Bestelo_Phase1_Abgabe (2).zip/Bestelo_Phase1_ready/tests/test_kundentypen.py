import pytest
from bestelo.kunden import Geschaeftskunde, Privatkunde, Verein


def test_ust_id_wird_normalisiert():
    g = Geschaeftskunde(1002, "Ben", "b@x.de", "Firma", "de 123 456 789")
    assert g.ust_id == "DE123456789"


@pytest.mark.parametrize("ust", ["12345678901", "AT123456789", "DE12345678A"])
def test_ungueltige_ust_id(ust):
    with pytest.raises(ValueError):
        Geschaeftskunde(1002, "Ben", "b@x.de", "Firma", ust)


def test_zahlungsziel_standard_und_validierung():
    g = Geschaeftskunde(1002, "Ben", "b@x.de", "Firma", "DE123456789")
    assert g.zahlungsziel_tage == 14
    with pytest.raises(ValueError, match="Zahlungsziel"):
        g.zahlungsziel_tage = 90


def test_geschaeftskunde_begruessung_str_und_rabatt():
    g = Geschaeftskunde(1002, "Ben Schmidt", "b@x.de", "Schmidt IT GmbH", "DE123456789")
    assert g.begruessung() == "Sehr geehrte Damen und Herren der Schmidt IT GmbH,"
    assert str(g) == "Kunde 1002: Schmidt IT GmbH (Ansprechpartner: Ben Schmidt)"
    assert g.rabattsatz() == 0.03


def test_verein_rabatt_und_registernummer():
    v = Verein(1003, "SV Musterstadt", "v@x.de", "VR 1234")
    assert v.rabattsatz() == 0.05
    v.gemeinnuetzig = False
    assert v.rabattsatz() == 0.02
    with pytest.raises(ValueError):
        v.registernummer = "1234"


def test_polymorphie_der_rabattsaetze():
    kunden = [Privatkunde(1001, "A", "a@x.de", 1995),
              Geschaeftskunde(1002, "B", "b@x.de", "Firma", "DE123456789"),
              Verein(1003, "Verein", "v@x.de", "VR 1234")]
    assert [k.rabattsatz() for k in kunden] == [0.0, 0.03, 0.05]
