from pathlib import Path
from bestelo.__main__ import main
from bestelo.bestellungen import Bestellung
from bestelo.kunden import Verein
from bestelo.produkte import Produkt

CSV = Path(__file__).parents[1] / "bestelo" / "daten" / "produkte.csv"


def test_vereinsbestellung_aus_csv():
    produkte = Produkt.aus_csv_datei(CSV)
    orange = next(p for p in produkte if p.artikelnummer == "P-1003")
    verein = Verein(1003, "SV Musterstadt", "info@sv.de", "VR 1234")
    bestellung = Bestellung(verein)
    bestellung.hinzufuegen(orange, 24)
    assert bestellung.brutto_summe == 75.97


def test_demo_zeigt_bruttosumme(capsys):
    main()
    ausgabe = capsys.readouterr().out
    assert "79.66" in ausgabe
    assert "75.97" in ausgabe
