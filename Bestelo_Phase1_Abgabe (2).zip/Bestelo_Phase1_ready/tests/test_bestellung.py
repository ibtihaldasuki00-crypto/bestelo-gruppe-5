import pytest
from bestelo.bestellungen import Bestellposition, Bestellung
from bestelo.kunden import Geschaeftskunde, Verein
from bestelo.produkte import Produkt


def beispielprodukte():
    return (Produkt("P-1001", "Kaffeebohnen 500 g", 8.90, "Lebensmittel"),
            Produkt("P-1002", "Mineralwasser 12 × 1 l", 7.50, "Getränke"))


def beispielkunde():
    return Geschaeftskunde(1002, "Ben Schmidt", "ben@x.de", "Schmidt IT GmbH", "DE123456789")


def test_bestellposition_betraege_und_str():
    kaffee, _ = beispielprodukte()
    p = Bestellposition(kaffee, 3)
    assert (p.netto, p.mwst, p.brutto) == (26.70, 1.87, 28.57)
    assert str(p) == "3 × Kaffeebohnen 500 g à 8.90 € = 26.70 €"


def test_menge_muss_mindestens_eins_sein():
    kaffee, _ = beispielprodukte()
    with pytest.raises(ValueError):
        Bestellposition(kaffee, 0)


def test_bestellung_rechenbeispiel():
    kaffee, wasser = beispielprodukte()
    b = Bestellung(beispielkunde())
    b.hinzufuegen(kaffee, 2)
    b.hinzufuegen(wasser, 6)
    b.hinzufuegen(kaffee)
    assert len(b) == 2
    assert (b.netto_summe, b.rabatt_betrag, b.netto_nach_rabatt,
            b.mwst_betrag, b.brutto_summe) == (71.70, 2.15, 69.55, 10.11, 79.66)


def test_gleiches_produkt_wird_zusammengefasst():
    kaffee, _ = beispielprodukte()
    b = Bestellung(beispielkunde())
    b.hinzufuegen(kaffee, 2)
    b.hinzufuegen(kaffee, 3)
    assert len(b.positionen) == 1
    assert b.positionen[0].menge == 5


def test_bestellnummern_laufen_weiter():
    a = Bestellung(beispielkunde())
    b = Bestellung(beispielkunde())
    assert int(b.bestellnummer[-4:]) == int(a.bestellnummer[-4:]) + 1


def test_abschliessen_und_aendern_verhindern():
    kaffee, _ = beispielprodukte()
    b = Bestellung(beispielkunde())
    with pytest.raises(ValueError):
        b.abschliessen()
    b.hinzufuegen(kaffee)
    b.abschliessen()
    b.abschliessen()
    with pytest.raises(ValueError, match="abgeschlossen"):
        b.hinzufuegen(kaffee)


def test_positionen_liefern_kopie():
    kaffee, _ = beispielprodukte()
    b = Bestellung(beispielkunde())
    b.hinzufuegen(kaffee)
    b.positionen.clear()
    assert len(b) == 1


def test_vereinsbestellung_24_orangensaft():
    orange = Produkt("P-1003", "Orangensaft 1 l", 2.80, "Getränke")
    b = Bestellung(Verein(1003, "SV Musterstadt", "v@x.de", "VR 1234"))
    b.hinzufuegen(orange, 24)
    assert b.brutto_summe == 75.97
