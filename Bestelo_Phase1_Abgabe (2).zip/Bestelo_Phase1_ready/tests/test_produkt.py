import pytest
from pathlib import Path
from bestelo.produkte import Produkt

CSV = Path(__file__).parents[1] / "bestelo" / "daten" / "produkte.csv"


def test_mwst_und_bruttopreis():
    food = Produkt("P-1001", "Kaffee", 8.90, "Lebensmittel")
    drink = Produkt("P-1002", "Wasser", 7.50, "Getränke")
    assert food.mwst_satz == 0.07
    assert food.bruttopreis == 9.52
    assert drink.mwst_satz == 0.19
    assert drink.bruttopreis == 8.92


@pytest.mark.parametrize("args", [("1001", "X", 1, "Sonstiges"),
                                   ("P-1001", " ", 1, "Sonstiges"),
                                   ("P-1001", "X", 0, "Sonstiges"),
                                   ("P-1001", "X", 1, "Unbekannt")])
def test_ungueltige_produktwerte(args):
    with pytest.raises(ValueError):
        Produkt(*args)


def test_csv_zeile():
    p = Produkt.aus_csv_zeile("P-1001;Kaffeebohnen 500 g;8.90;Lebensmittel\n")
    assert p.artikelnummer == "P-1001"
    assert p.nettopreis == 8.90


def test_csv_datei_und_guenstigstes_produkt():
    produkte = Produkt.aus_csv_datei(CSV)
    assert len(produkte) == 6
    assert min(produkte).artikelnummer == "P-1003"


def test_vergleich_und_sortierung():
    a = Produkt("P-1001", "Kaffee", 8.90, "Lebensmittel")
    b = Produkt("P-1002", "Wasser", 7.50, "Getränke")
    assert b < a
    assert a == Produkt("P-1001", "Andere", 1, "Sonstiges")
    assert [p.artikelnummer for p in sorted([a, b])] == ["P-1002", "P-1001"]
