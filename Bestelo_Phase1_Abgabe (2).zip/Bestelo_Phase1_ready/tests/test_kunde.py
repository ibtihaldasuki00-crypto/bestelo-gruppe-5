import pytest
from bestelo.kunden import Kunde, Privatkunde


def test_kunde_name_wird_getrimmt_und_strings():
    k = Kunde(1001, " Anna Müller ", "anna@example.com")
    assert k.name == "Anna Müller"
    assert str(k) == "Kunde 1001: Anna Müller"
    assert repr(k) == "Kunde(1001, 'Anna Müller')"


def test_ungueltige_email():
    with pytest.raises(ValueError):
        Kunde(1001, "Anna", "anna.example.com")


def test_name_darf_nicht_leer_sein():
    k = Kunde(1001, "Anna", "anna@example.com")
    with pytest.raises(ValueError, match="Name darf nicht leer sein"):
        k.name = "  "


def test_kundennummer_nur_lesbar_und_validiert():
    k = Kunde(1001, "Anna", "anna@example.com")
    with pytest.raises(AttributeError):
        k.kundennummer = 5
    with pytest.raises(ValueError):
        Kunde(999, "Anna", "anna@example.com")


def test_gleichheit_nach_kundennummer():
    assert Kunde(1001, "A", "a@x.de") == Kunde(1001, "B", "b@x.de")
    assert Kunde(1001, "A", "a@x.de") != Kunde(1002, "B", "b@x.de")


def test_privatkunde_alter_und_rabatt():
    p = Privatkunde(1001, "Anna", "a@x.de", 1995, True)
    assert p.alter(2026) == 31
    assert p.rabattsatz() == 0.02
    p.stammkunde = False
    assert p.rabattsatz() == 0.0


def test_privatkunde_ungueltiges_geburtsjahr():
    with pytest.raises(ValueError):
        Privatkunde(1001, "Anna", "a@x.de", 1899)
