"""Konsolen-Demo: python -m bestelo."""
from pathlib import Path

from bestelo.bestellungen import Bestellung
from bestelo.kunden import Geschaeftskunde, Kunde, Privatkunde, Verein
from bestelo.produkte import Produkt

CSV_PFAD = Path(__file__).parent / "daten" / "produkte.csv"


def beleg_drucken(bestellung: Bestellung) -> None:
    print("=" * 50)
    print(f"Bestellung {bestellung.bestellnummer} ({bestellung.status})")
    print(bestellung.kunde.begruessung())
    print("-" * 50)
    for position in bestellung.positionen:
        print(position)
    print("-" * 50)
    print(f"{'Netto:':<16}{bestellung.netto_summe:>9.2f} €")
    print(f"{'Rabatt ' + format(bestellung.kunde.rabattsatz(), '.0%') + ':':<16}{-bestellung.rabatt_betrag:>9.2f} €")
    print(f"{'MwSt.:':<16}{bestellung.mwst_betrag:>9.2f} €")
    print(f"{'Brutto:':<16}{bestellung.brutto_summe:>9.2f} €")
    print()


def main() -> None:
    produkte = Produkt.aus_csv_datei(CSV_PFAD)
    print("Sortiment (nach Preis):")
    for produkt in sorted(produkte):
        print(f"  {produkt}")
    print()

    kunden: list[Kunde] = [
        Privatkunde(1001, "Anna Müller", "anna@example.com", 1995, stammkunde=True),
        Geschaeftskunde(1002, "Ben Schmidt", "ben@schmidt-it.de", "Schmidt IT GmbH", "DE123456789"),
        Verein(1003, "SV Musterstadt", "info@sv-musterstadt.de", "VR 1234"),
    ]
    for kunde in kunden:
        print(f"{kunde} – {kunde.rabattsatz():.0%} Rabatt")
    print()

    nach_nummer = {produkt.artikelnummer: produkt for produkt in produkte}
    bestellung = Bestellung(kunden[1])
    bestellung.hinzufuegen(nach_nummer["P-1001"], 3)
    bestellung.hinzufuegen(nach_nummer["P-1002"], 6)
    bestellung.abschliessen()
    beleg_drucken(bestellung)

    vereinsbestellung = Bestellung(kunden[2])
    vereinsbestellung.hinzufuegen(nach_nummer["P-1003"], 24)
    print(vereinsbestellung)


if __name__ == "__main__":
    main()
