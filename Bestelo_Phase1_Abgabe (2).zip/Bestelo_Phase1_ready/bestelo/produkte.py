"""Produktmodell und CSV-Import."""
from pathlib import Path


class Produkt:
    KATEGORIEN = ("Lebensmittel", "Getränke", "Bücher", "Haushalt", "Elektronik", "Sonstiges")
    ERMAESSIGTE_KATEGORIEN = ("Lebensmittel", "Bücher")
    MWST_ERMAESSIGT = 0.07
    MWST_REGULAER = 0.19

    def __init__(self, artikelnummer: str, bezeichnung: str, nettopreis: float,
                 kategorie: str = "Sonstiges") -> None:
        if not isinstance(artikelnummer, str) or len(artikelnummer) != 6 or not artikelnummer.startswith("P-") or not artikelnummer[2:].isdigit():
            raise ValueError("Artikelnummer muss aus 'P-' und vier Ziffern bestehen")
        self._artikelnummer = artikelnummer
        self.bezeichnung = bezeichnung
        self.nettopreis = nettopreis
        self.kategorie = kategorie

    @property
    def artikelnummer(self) -> str:
        return self._artikelnummer

    @property
    def bezeichnung(self) -> str:
        return self._bezeichnung

    @bezeichnung.setter
    def bezeichnung(self, wert: str) -> None:
        if not isinstance(wert, str) or not wert.strip():
            raise ValueError("Bezeichnung darf nicht leer sein")
        self._bezeichnung = wert.strip()

    @property
    def nettopreis(self) -> float:
        return self._nettopreis

    @nettopreis.setter
    def nettopreis(self, wert: float) -> None:
        try:
            preis = float(wert)
        except (TypeError, ValueError):
            raise ValueError("Nettopreis muss größer als 0 sein") from None
        if preis <= 0:
            raise ValueError("Nettopreis muss größer als 0 sein")
        self._nettopreis = round(preis, 2)

    @property
    def kategorie(self) -> str:
        return self._kategorie

    @kategorie.setter
    def kategorie(self, wert: str) -> None:
        if wert not in self.KATEGORIEN:
            raise ValueError("Unbekannte Kategorie")
        self._kategorie = wert

    @property
    def mwst_satz(self) -> float:
        return self.MWST_ERMAESSIGT if self.kategorie in self.ERMAESSIGTE_KATEGORIEN else self.MWST_REGULAER

    @property
    def bruttopreis(self) -> float:
        return round(self.nettopreis * (1 + self.mwst_satz), 2)

    @classmethod
    def aus_csv_zeile(cls, zeile: str) -> "Produkt":
        teile = zeile.strip().split(";")
        if len(teile) != 4:
            raise ValueError("CSV-Zeile muss genau vier Felder enthalten")
        artikelnummer, bezeichnung, nettopreis, kategorie = teile
        return cls(artikelnummer, bezeichnung, float(nettopreis), kategorie)

    @classmethod
    def aus_csv_datei(cls, pfad: str | Path) -> list["Produkt"]:
        with open(pfad, encoding="utf-8") as datei:
            next(datei, None)
            return [cls.aus_csv_zeile(zeile) for zeile in datei if zeile.strip()]

    def __str__(self) -> str:
        return f"{self.artikelnummer} {self.bezeichnung} – {self.nettopreis:.2f} € netto"

    def __repr__(self) -> str:
        return f"Produkt({self.artikelnummer!r}, {self.bezeichnung!r}, {self.nettopreis!r}, {self.kategorie!r})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Produkt):
            return NotImplemented
        return self.artikelnummer == other.artikelnummer

    def __lt__(self, other: object) -> bool:
        if not isinstance(other, Produkt):
            return NotImplemented
        return self.nettopreis < other.nettopreis
