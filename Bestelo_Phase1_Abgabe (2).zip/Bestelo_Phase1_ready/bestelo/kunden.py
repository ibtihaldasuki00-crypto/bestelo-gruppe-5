"""Kunden und Kundentypen für Bestelo."""
from datetime import date


class Kunde:
    def __init__(self, kundennummer: int, name: str, email: str) -> None:
        if not isinstance(kundennummer, int) or kundennummer < 1000:
            raise ValueError("Kundennummer muss mindestens 1000 sein")
        self._kundennummer = kundennummer
        self.name = name
        self.email = email

    @property
    def kundennummer(self) -> int:
        return self._kundennummer

    @property
    def name(self) -> str:
        return self._name

    @name.setter
    def name(self, wert: str) -> None:
        if not isinstance(wert, str) or not wert.strip():
            raise ValueError("Name darf nicht leer sein")
        self._name = wert.strip()

    @property
    def email(self) -> str:
        return self._email

    @email.setter
    def email(self, wert: str) -> None:
        if not self.ist_gueltige_email(wert):
            raise ValueError("Ungültige E-Mail-Adresse")
        self._email = wert.strip()

    @staticmethod
    def ist_gueltige_email(email: str) -> bool:
        if not isinstance(email, str) or "@" not in email:
            return False
        return "." in email.split("@", 1)[1]

    def begruessung(self) -> str:
        return f"Hallo {self.name}!"

    def rabattsatz(self) -> float:
        return 0.0

    def __str__(self) -> str:
        return f"Kunde {self.kundennummer}: {self.name}"

    def __repr__(self) -> str:
        return f"{type(self).__name__}({self.kundennummer}, {self.name!r})"

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, Kunde):
            return NotImplemented
        return self.kundennummer == other.kundennummer


class Privatkunde(Kunde):
    def __init__(self, kundennummer: int, name: str, email: str,
                 geburtsjahr: int, stammkunde: bool = False) -> None:
        super().__init__(kundennummer, name, email)
        self.geburtsjahr = geburtsjahr
        self.stammkunde = stammkunde

    @property
    def geburtsjahr(self) -> int:
        return self._geburtsjahr

    @geburtsjahr.setter
    def geburtsjahr(self, wert: int) -> None:
        if not isinstance(wert, int) or not 1900 <= wert <= date.today().year:
            raise ValueError("Geburtsjahr muss zwischen 1900 und dem aktuellen Jahr liegen")
        self._geburtsjahr = wert

    def alter(self, stichjahr: int | None = None) -> int:
        if stichjahr is None:
            stichjahr = date.today().year
        return stichjahr - self.geburtsjahr

    def rabattsatz(self) -> float:
        return 0.02 if self.stammkunde else 0.0


class Geschaeftskunde(Kunde):
    def __init__(self, kundennummer: int, name: str, email: str, firmenname: str,
                 ust_id: str, zahlungsziel_tage: int = 14) -> None:
        super().__init__(kundennummer, name, email)
        self.firmenname = firmenname
        self.ust_id = ust_id
        self.zahlungsziel_tage = zahlungsziel_tage

    @property
    def firmenname(self) -> str:
        return self._firmenname

    @firmenname.setter
    def firmenname(self, wert: str) -> None:
        if not isinstance(wert, str) or not wert.strip():
            raise ValueError("Firmenname darf nicht leer sein")
        self._firmenname = wert.strip()

    @property
    def ust_id(self) -> str:
        return self._ust_id

    @ust_id.setter
    def ust_id(self, wert: str) -> None:
        normalisiert = "".join(wert.split()).upper() if isinstance(wert, str) else ""
        if len(normalisiert) != 11 or not normalisiert.startswith("DE") or not normalisiert[2:].isdigit():
            raise ValueError("Ungültige USt-IdNr.")
        self._ust_id = normalisiert

    @property
    def zahlungsziel_tage(self) -> int:
        return self._zahlungsziel_tage

    @zahlungsziel_tage.setter
    def zahlungsziel_tage(self, wert: int) -> None:
        if not isinstance(wert, int) or not 0 <= wert <= 60:
            raise ValueError("Zahlungsziel muss zwischen 0 und 60 Tagen liegen")
        self._zahlungsziel_tage = wert

    def begruessung(self) -> str:
        return f"Sehr geehrte Damen und Herren der {self.firmenname},"

    def rabattsatz(self) -> float:
        return 0.03

    def __str__(self) -> str:
        return f"Kunde {self.kundennummer}: {self.firmenname} (Ansprechpartner: {self.name})"


class Verein(Kunde):
    def __init__(self, kundennummer: int, name: str, email: str,
                 registernummer: str, gemeinnuetzig: bool = True) -> None:
        super().__init__(kundennummer, name, email)
        self.registernummer = registernummer
        self.gemeinnuetzig = gemeinnuetzig

    @property
    def registernummer(self) -> str:
        return self._registernummer

    @registernummer.setter
    def registernummer(self, wert: str) -> None:
        if not isinstance(wert, str) or not wert.startswith("VR ") or not wert[3:].isdigit():
            raise ValueError("Registernummer muss mit 'VR ' beginnen und danach Ziffern enthalten")
        self._registernummer = wert

    def begruessung(self) -> str:
        return f"An den Vorstand des Vereins {self.name}"

    def rabattsatz(self) -> float:
        return 0.05 if self.gemeinnuetzig else 0.02
