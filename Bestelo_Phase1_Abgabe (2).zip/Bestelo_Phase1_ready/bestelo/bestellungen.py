"""Bestellpositionen und Bestellungen."""
from bestelo.kunden import Kunde
from bestelo.produkte import Produkt


class Bestellposition:
    def __init__(self, produkt: Produkt, menge: int = 1) -> None:
        if not isinstance(produkt, Produkt):
            raise ValueError("Eine gültige Produkt-Instanz ist erforderlich")
        self._produkt = produkt
        self.menge = menge

    @property
    def produkt(self) -> Produkt:
        return self._produkt

    @property
    def menge(self) -> int:
        return self._menge

    @menge.setter
    def menge(self, wert: int) -> None:
        if not isinstance(wert, int) or wert < 1:
            raise ValueError("Menge muss mindestens 1 sein")
        self._menge = wert

    @property
    def netto(self) -> float:
        return round(self.produkt.nettopreis * self.menge, 2)

    @property
    def mwst(self) -> float:
        return round(self.netto * self.produkt.mwst_satz, 2)

    @property
    def brutto(self) -> float:
        return round(self.netto + self.mwst, 2)

    def __str__(self) -> str:
        return f"{self.menge} × {self.produkt.bezeichnung} à {self.produkt.nettopreis:.2f} € = {self.netto:.2f} €"


class Bestellung:
    _naechste_nummer = 1

    def __init__(self, kunde: Kunde) -> None:
        if not isinstance(kunde, Kunde):
            raise ValueError("Eine gültige Kunde-Instanz ist erforderlich")
        nummer = Bestellung._naechste_nummer
        Bestellung._naechste_nummer += 1
        self._bestellnummer = f"B-{nummer:04d}"
        self._kunde = kunde
        self._status = "offen"
        self._positionen: list[Bestellposition] = []

    @property
    def bestellnummer(self) -> str:
        return self._bestellnummer

    @property
    def kunde(self) -> Kunde:
        return self._kunde

    @property
    def status(self) -> str:
        return self._status

    @property
    def positionen(self) -> list[Bestellposition]:
        return list(self._positionen)

    @property
    def netto_summe(self) -> float:
        return round(sum(p.netto for p in self._positionen), 2)

    @property
    def rabatt_betrag(self) -> float:
        return round(self.netto_summe * self.kunde.rabattsatz(), 2)

    @property
    def netto_nach_rabatt(self) -> float:
        return round(self.netto_summe - self.rabatt_betrag, 2)

    @property
    def mwst_betrag(self) -> float:
        return round(sum(p.mwst for p in self._positionen) * (1 - self.kunde.rabattsatz()), 2)

    @property
    def brutto_summe(self) -> float:
        return round(self.netto_nach_rabatt + self.mwst_betrag, 2)

    def hinzufuegen(self, produkt: Produkt, menge: int = 1) -> None:
        if self.status != "offen":
            raise ValueError("Bestellung ist bereits abgeschlossen")
        if not isinstance(menge, int) or menge < 1:
            raise ValueError("Menge muss mindestens 1 sein")
        for position in self._positionen:
            if position.produkt == produkt:
                position.menge += menge
                return
        self._positionen.append(Bestellposition(produkt, menge))

    def abschliessen(self) -> None:
        if self.status == "abgeschlossen":
            return
        if not self._positionen:
            raise ValueError("Leere Bestellung kann nicht abgeschlossen werden")
        self._status = "abgeschlossen"

    def __len__(self) -> int:
        return len(self._positionen)

    def __str__(self) -> str:
        return (f"Bestellung {self.bestellnummer} ({self.status}) für {self.kunde.name}: "
                f"{len(self)} Position(en), {self.brutto_summe:.2f} € brutto")
